# CS337 Project 1: Twitter
Golden Globe Project Master
By Callum Bondy (cbf3357), Helena Guajardo (hcg8373), and Hayden Ufberg (hbu8846)

The adress for the github repository is: https://github.com/cbondy100/CS337-Project-1

Needed Packages:
NLTk
To download, run in terminal:
  pip install --user -U nltk
  
We use an IMDB dataset to check if potential nominees are actors. It is necessary to download the dataset at the link below. Then, it must be put into the data folder in the repository so that it can be accessed by the API. 

When our API is run, it returns a human readable output with the information. 

For IMDb datasets:
download the name.basics.tsv.gc
It is available at this link:
https://www.imdb.com/interfaces/
